package model;

public class UnrecognizedVaccineCodeNameException extends Exception  {
	UnrecognizedVaccineCodeNameException(String s) {
		super(s);
	}
}
