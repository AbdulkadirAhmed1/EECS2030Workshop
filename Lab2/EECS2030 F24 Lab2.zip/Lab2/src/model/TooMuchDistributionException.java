package model;

public class TooMuchDistributionException extends Exception  {
	TooMuchDistributionException(String s) {
		super(s);
	}

}
