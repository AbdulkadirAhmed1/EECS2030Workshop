package model;

public class InsufficientVaccineDosesException extends Exception  {
	InsufficientVaccineDosesException(String s) {
		super(s);
	}

}
